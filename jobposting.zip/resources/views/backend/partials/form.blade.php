<div class="modal fade" tabindex="-1" id="appForm" data-bs-focus="false" data-bs-backdrop="static" aria-labelledby="appFormLabel" aria-hidden="true">
	<div class="modal-dialog {{ $modal_type }} modal-fullscreen-md-down modal-dialog-scrollable">
		<div class="modal-content bg-white">
			<div class="modal-header">
				<h5 class="modal-title" id="appFormLabel"></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body p-2">
			</div>
		</div>
	</div>
</div>