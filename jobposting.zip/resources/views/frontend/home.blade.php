@include('frontend.content.image slider')
<div class="container" style="z-index: 11; position: relative;">
	@include('frontend.content.pencarian')
</div>
@include('frontend.content.alasan memilih run8')
@include('frontend.content.informasi lowongan')
@include('frontend.content.klien alih daya')
@include('frontend.partials.footer')