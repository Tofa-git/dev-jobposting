<!DOCTYPE html>
<html>
<head>
	<title>FreeCMS</title>
</head>
<body>
	<h1>HTTP Status 403 - Access Denied</h1>
	You don't have permission to access this page. Please contact your administrator to request access.<br />
	{{ 'https://'.$_SERVER['HTTP_HOST'].', '.$_SERVER['HTTP_USER_AGENT'] }}
	<br /><br />
	<a href="{{ url()->previous() }}">Go to previous page</a>
</body>
</html>