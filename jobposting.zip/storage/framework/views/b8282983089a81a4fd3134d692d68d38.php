<?php $__env->startSection('header_style'); ?>
    <?php
        $menu = \App\Models\frontend_menu::selectRaw('tbl_frontend_menu.id, tbl_frontend_menu.menu_type, tbl_frontend_menu.caption, tbl_frontend_menu.target_slug, tbl_frontend_menu.action, count(b.id) as jml_sub')
            -> leftJoin('tbl_frontend_menu as b', 'b.refid', '=', 'tbl_frontend_menu.id')
            -> whereRaw('tbl_frontend_menu.status="0" And tbl_frontend_menu.refid=0 And tbl_frontend_menu.published_by > 0 And Not IsNull(tbl_frontend_menu.published_at)')
            -> groupByRaw('tbl_frontend_menu.id')
            -> get();
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php echo $__env->make($pages, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\runlapan\jobposting\resources\views/welcome.blade.php ENDPATH**/ ?>