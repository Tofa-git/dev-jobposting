<div class="flex-shrink-1 w-100 m-0 p-1 px-3 d-flex bg-white ms-2 mt-1 border" style="border-top-left-radius: 10px">
	<div class="flex-grow-1 small">
		<?php echo @$info->copyright ?? 'Footer Informations'; ?>

	</div>
	<div class="small">
		<?php echo e(\App\Helpers\general::formatTanggal(now(), 'DD MMM YYYY')); ?>

	</div>
</div><?php /**PATH D:\xampp8.2\htdocs\runlapan\jobposting\resources\views/backend/partials/footer.blade.php ENDPATH**/ ?>