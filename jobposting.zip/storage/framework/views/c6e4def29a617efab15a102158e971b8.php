<?php
    $_photo = null;
?>
<div class="d-none bg-white d-lg-flex flex-fill flex-column" style="min-width: 300px">
	<div class="p-0 flex-shrink-1" style="background-repeat: no-repeat; background-size: cover; background-position: center; background-image: url(<?php echo e(asset('assets/images/background.jpg')); ?>);">
			<div class="d-flex align-items-center p-3" style="background-color: rgba(0,0,128,0.75)">
				<div class="avatar" style=" background-image: url(<?php echo e(\App\Models\data_file::getAvatar(\Auth::user()->picture)); ?>);">
				</div>
				<div class="ps-3" style="overflow: hidden;">
					<div class="fs-6 text-light lh-sm"><strong><?php echo e(\Auth::user()->name); ?></strong></div>
					<div class="small text-light lh-sm"><?php echo e(\Auth::user()->email); ?></div>
				</div>
			</div>
	</div>
	<div class="d-flex flex-fill flex-column overflow-auto">
		<div class="flex-grow-1 p-0">
			<?php if(\Auth::user()->status === '0'): ?>
				<?php echo \App\Models\backend_menu::renderMenu($activeMenu); ?>

			<?php endif; ?>
		</div>
	</div>
</div><?php /**PATH D:\xampp8.2\htdocs\runlapan\jobposting\resources\views/backend/partials/menu.blade.php ENDPATH**/ ?>