<div class="offcanvas offcanvas-start d-lg-none d-inline-block" tabindex="-1" id="mobileAppMenu" aria-labelledby="mobileAppMenuLabel">
	<div class="offcanvas-header">
		<a href="/dashboard" class="navbar-brand m-0 px-2 bg-teal-hover d-flex align-self-center">
			<div class="d-flex align-items-center">
				<img src="<?php echo e(\App\Models\data_file::getLogo(@$info->logo)); ?>" class="img-fluid" style="max-height: 40px; height: auto; display: inline-block; vertical-align: middle;" class="img-fluid">
				<div class="ps-2 d-inline-block d-md-none">
					<span style="display: block; font-size: 10pt; line-height: 20px; font-weight: bold;"><?php echo e($info->icon_text_1); ?></span>
					<span style="display: block; font-size: 10pt; color: black; line-height: 16px;"><?php echo e($info->icon_text_2); ?></span>
				</div>
			</div>
		</a>
		<button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
	</div>
	<div class="offcanvas-body">
		<div class="accordion accordion-dark bg-transparent accordion-flush text-light" id="accordionFlushExample">
			<?php $__currentLoopData = $backend_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_backend_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="accordion-item bg-transparent" style="border: none!important; box-shadow: none;">
					<?php if($_backend_menu->menu_type===4): ?>
						<li class="nav-item bg-teal-hover">
							<a class="nav-link text-nowrap mx-3" href="<?php echo e($_backend_menu->action); ?>"><?php echo e($_backend_menu->caption); ?></a>
						</li>
					<?php elseif($_backend_menu->menu_type===5): ?>
					<?php elseif($_backend_menu->menu_type===6): ?>
						<li class="nav-item">
							<div class="border-top"></div>
						</li>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
</div><?php /**PATH D:\xampp8.2\htdocs\runlapan\jobposting\resources\views/backend/partials/menu mobile.blade.php ENDPATH**/ ?>