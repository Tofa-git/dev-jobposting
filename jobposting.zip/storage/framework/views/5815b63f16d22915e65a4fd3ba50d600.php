<div class="ms-2 p-1 px-3 bg-white shadow-sm" style="border-bottom-left-radius: 10px">
	<span class="fs-4 fw-lighter"><?php echo e($title); ?></span>
</div>
<div class="d-flex flex-fill flex-column shadow-sm bg-white overflow-auto ms-2 mt-1" style="border-top-left-radius: 10px; border-bottom-left-radius: 10px; border-top: 1px solid #dddddd; border-left: 1px solid #dddddd; border-bottom: 1px solid #dddddd;">
	<div class="flex-shrink-1">
		<div class="d-flex border-bottom p-2 px-3">
			<div class="d-flex flex-grow-1">
				<form class="d-flex flex-row flex-fill">
					<input type="hidden" name="method" value="<?php echo e(@$_REQUEST['method']); ?>" />
					<input type="hidden" name="platform" value="<?php echo e(@$_REQUEST['platform']); ?>" />
					<input type="hidden" name="browser" value="<?php echo e(@$_REQUEST['browser']); ?>" />
					<div style="width: 150px">
						<select class="form-select rounded-0 bg-white" name="total">
							<option value="25" <?php if((int)$total === 25): ?> selected <?php endif; ?>>25 Baris</option>
							<option value="50" <?php if((int)$total === 50): ?> selected <?php endif; ?>>50 Baris</option>
							<option value="100" <?php if((int)$total === 100): ?> selected <?php endif; ?>>100 Baris</option>
						</select>
					</div>
					<div class="flex-grow-1 input-group m-0 ms-2 d-none d-sm-flex">
						<input name="q" type="text" class="form-control bg-white rounded-0 p-0 px-3" value="<?php echo e(@$_REQUEST['q']); ?>" placeholder="Descriptions">
						<div class="input-group-append">
							<div class="btn-group">
								<button class="btn btn-outline-primary rounded-0 p-1 px-2" type="submit" title="Go Search"><i class="material-icons-outlined align-middle align-self-center">search</i></button>
								<a class="btn btn-outline-secondary rounded-0 p-1 px-2" id="filter_button" role="button" title="Search options" data-bs-toggle="offcanvas" href="#offcanvasExample" aria-controls="offcanvasExample"><i class="material-icons-outlined align-middle align-self-center">filter_alt</i></a>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="d-flex flex-fill flex-column p-0 px-3" style="overflow-x: auto!important;">
		<table class="table table-striped table-hover w-100" cellpadding="0" cellspacing="0">
			<thead>
				<tr class="text-nowrap">
					<th width="30px">No</th>
					<th width="30px">Datetime</th>
					<th width="30px">User Account</th>
					<th>Descriptions</th>
					<th width="30px">Method</th>
					<th width="30px">IP</th>
					<th width="30px">Platform</th>
					<th width="30px">Browser</th>
					<th width="30px">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php if($data->isEmpty()): ?>
					<tr class="bg-white">
						<td align="center">*</td>
						<td colspan="8">Data tidak ditemukan</td>
					</tr>
				<?php else: ?>
					<?php $_i=$data->firstItem(); ?>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr valign="top" <?php if($_i % 2===0): ?> class="bg-light" <?php else: ?> class="bg-white" <?php endif; ?>>
							<td align="center"><?php echo e($_i); ?>.</td>
							<td align="center" class="text-nowrap"><?php echo e($_data->created_at); ?></td>
							<td class="text-nowrap"><?php echo e($_data->userAccount->email ?? '[ANONYMOUS]'); ?></td>
							<td style="min-width: 200px; white-space: normal;">
								<?php echo e($_data->title); ?>

								<div class="text-primary"><?php echo e($_data->description); ?></div>
							</td>
							<td><?php echo e($_data->method); ?></td>
							<td align="center"><?php echo e($_data->ip4); ?></td>
							<td><?php echo e($_data->platform); ?></td>
							<td class="text-nowrap"><?php echo e($_data->browser.' '.$_data->browser_version); ?></td>
							<td align="center">
								<?php if(\Auth::user()->hasPermission('Halaman Website', 'delete')): ?>
									<form method="post" onsubmit="return confirm('Are you sure want to delete this record?')" action="<?php echo e(route('log-activities.destroy', $_data)); ?>" class="d-inline">
										<?php echo csrf_field(); ?>
										<?php echo method_field('delete'); ?>
										<button type="submit" class="btn btn-outline-danger btn-sm ms-1 p-0 px-2" title="Delete" role="button">
											<i class="material-icons-outlined p-1 d-flex fs-6">clear</i>
										</button>
									</form>
								<?php endif; ?>
							</td>
						</tr>
						<?php $_i++; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
	<div class="flex-shrink-1">
		<div class="p-2 px-3 d-flex flex-row flex-fill border-top bg-light">
			<div class="d-md-inline d-none small flex-grow-1">Menampilkan <?php echo e((int)$data->firstItem().' sampai '.(int)$data->lastItem()); ?> dari <?php echo e($data->total().' baris'); ?></div>
			<div><?php echo str_replace('pagination', 'pagination pagination-sm no-gap mb-0 place-right', $data->onEachSide(1)->render('pagination::bootstrap-4')); ?></div>
		</div>
	</div>
</div>

<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
	<div class="offcanvas-header">
		<h5 class="offcanvas-title" id="offcanvasExampleLabel">Search Options</h5>
		<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
	</div>
	<div class="offcanvas-body">
		<form>
			<div class="row">
				<div class="col-sm-4 small">Tampilkan</div>
				<div class="col-sm-8">
					<select class="form-select rounded-0 bg-white" name="total" id="total">
						<option value="25" <?php if((int)$total === 25): ?> selected <?php endif; ?>>25</option>
						<option value="50" <?php if((int)$total === 50): ?> selected <?php endif; ?>>50</option>
						<option value="100" <?php if((int)$total === 100): ?> selected <?php endif; ?>>100</option>
					</select>
				</div>
			</div>
			<div class="row mt-1">
				<div class="col-sm-4 small">Platform</div>
				<div class="col-sm-8">
					<select class="rounded-0 bg-white form-select" name="platform" id="platform">
						<option selected disabled>Seluruh Platform</option>
						<?php $__currentLoopData = $platform; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($_platform->platform); ?>" <?php if(@$_REQUEST['platform'] === $_platform->platform): ?> selected <?php endif; ?>><?php echo e(strtoupper($_platform->platform)); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="row mt-1">
				<div class="col-sm-4 small">Browser</div>
				<div class="col-sm-8">
					<select class="rounded-0 bg-white form-select" name="browser" id="browser">
						<option selected disabled>Seluruh Browser</option>
						<?php $__currentLoopData = $browser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_browser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($_browser->browser); ?>" <?php if(@$_REQUEST['browser'] === $_browser->browser): ?> selected <?php endif; ?>><?php echo e(strtoupper($_browser->browser)); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="row mt-1">
				<div class="col-sm-4 small">Method</div>
				<div class="col-sm-8">
					<select class="rounded-0 bg-white form-select" name="method" id="method">
						<option selected disabled>Seluruh Method</option>
						<?php $__currentLoopData = $method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($_method->method); ?>" <?php if(@$_REQUEST['method'] === $_method->method): ?> selected <?php endif; ?>><?php echo e(strtoupper($_method->method)); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="row mt-1">
				<div class="col-sm-4 small">Deskripsi</div>
				<div class="col-sm-8"><input type="text" class="form-control rounded-0 bg-white" name="q" placeholder="Deskripsi data" value="<?php echo e(@$_REQUEST['q']); ?>" /></div>
			</div>
			<hr />
			<button type="submit" class="btn btn-outline-primary rounded-0">Lakukan Pencarian</button>
		</form>
	</div>
</div><?php /**PATH D:\xampp8.2\htdocs\runlapan\jobposting\resources\views/backend/log activities/index.blade.php ENDPATH**/ ?>