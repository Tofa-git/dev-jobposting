<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>
    <div class="d-flex vh-100">
        <?php echo $__env->make('backend.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex flex-fill w-100 flex-column" style="transition: width 2s">
            <?php echo $__env->make('backend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make($pages, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('backend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <?php echo $__env->make('backend.partials.menu mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script type="module">
        <?php if(session()->has('message')): ?>
            toastr.success("<?php echo e(Session::get('message')); ?>");
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            toastr.error("<?php echo e(Session::get('error')); ?>");
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error("<?php echo e($error); ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(session()->has('modal')): ?>
            $(document).ready(function(){
                var _content = '<?php echo Session::get("content"); ?>';
                $('#appForm .modal-body').html(_content);
                $('#appFormLabel').text("<?php echo e(Session::get('title')); ?>");
                const myModal = new bootstrap.Modal(document.getElementById('appForm'), {
                    keyboard: false
                });
                myModal.show();
            });
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldContent('footer_style_script'); ?>
</body>
</html><?php /**PATH D:\xampp8.2\htdocs\runlapan\jobposting\resources\views/layouts/app.blade.php ENDPATH**/ ?>