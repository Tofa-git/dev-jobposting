<?php $__env->startSection('header_style'); ?>
    <?php
        $info = \App\Models\app_properties::first();
        $backend_menu = \App\Models\backend_menu::getDataMenu(0);
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\runlapan\jobposting\resources\views/home.blade.php ENDPATH**/ ?>