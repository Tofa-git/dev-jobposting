/*
SQLyog Enterprise - MySQL GUI v8.2 RC2
MySQL - 5.5.5-10.4.24-MariaDB : Database - db_berkala
*********************************************************************
*/

/*Data for the table `tbl_master_data` */

insert  into `tbl_master_data`(`id`,`type`,`description`,`status`,`created_by`,`updated_by`,`created_at`,`updated_at`,`deleted_at`) values (1,'0','Account Type','0',1,0,'2024-02-11 08:53:39',NULL,NULL),(2,'0','Menu Type','0',1,0,'2024-02-11 08:53:39',NULL,NULL);