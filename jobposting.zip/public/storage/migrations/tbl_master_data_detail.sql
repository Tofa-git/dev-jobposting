/*
SQLyog Enterprise - MySQL GUI v8.2 RC2
MySQL - 5.5.5-10.4.24-MariaDB : Database - db_berkala
*********************************************************************
*/

/*Data for the table `tbl_master_data_detail` */

insert  into `tbl_master_data_detail`(`id`,`refid`,`sequence`,`shortname`,`description`,`status`,`created_by`,`updated_by`,`created_at`,`updated_at`,`deleted_at`) values (1,1,1,NULL,'Developer','0',1,0,'2024-02-11 08:53:39',NULL,NULL),(2,1,2,NULL,'Super Administrator','0',1,0,'2024-02-11 08:53:39','2024-02-11 09:16:37',NULL),(3,1,3,NULL,'Administrator','0',1,0,'2024-02-11 08:53:39','2024-02-11 09:16:46',NULL),(4,2,1,NULL,'Menu Title','0',1,0,'2024-02-11 08:53:39',NULL,NULL),(5,2,2,NULL,'Menu','0',1,0,'2024-02-11 08:53:39',NULL,NULL),(6,2,3,NULL,'Separator','0',1,0,'2024-02-11 08:53:39',NULL,NULL),(7,1,0,NULL,'Admin SKPD','0',1,1,'2024-02-11 09:17:26','2024-02-11 09:18:03',NULL);
